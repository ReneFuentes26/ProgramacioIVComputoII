<?php
define("TITTLE","Mi cuenta");
define("SETTING","Configuracion de la cuenta");