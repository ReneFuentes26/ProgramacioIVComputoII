<?php 
    //Incluimos el archivo que contiene las funciones
    include "functions.php";

    //Obtener la accion a realizar
    $action=$_POST['action'];

    //obtener los valores del formulario
    $name = $_POST['name'];
    $lastname = $_POST['lastname'];
    $age = $_POST['age'];

    //Evaluamos las acciones
    if($action == "guardar"){
        saveData($name,$lastname,$age);
        //Redirigimos al index
        header('Location: index.php');
    }
    //funcio para editar registro
    if($action =="editar"){
         $cod = $_POST['cod'];

         //actualizar datos
         updateData($cod,$name,$lastname,$age);

         //Redirigir
         header('Location: index.php');
    }

    //Eliminar registro
    if($action == "eliminar"){
        $cod = $_POST['cod'];

        //LLamado de la funcion eliminar
        deleteData($cod);

        header('Location: index.php');
    }

?>