<?php
define("TITTLE","My Account");
define("SETTING","Account Settings");