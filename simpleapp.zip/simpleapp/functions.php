<?php

    //Archivo de texto
    //$file= "datos.txt";
    //si fuera una constante 
    define("FILE","datos.txt");

    //Funcio que lista los datos 
    function getData(){
        //Si el archivo no existe lo creamos 
        if(!file_exists(FILE)){
            file_put_contents(FILE,'');
        }
        //obtener los datos del archivo 
        $data = file_get_contents(FILE);
        $data = json_decode($data,true);

        if(!is_array($data)){
            $data=array();
        }
        return $data
    
    ;}


    //Funcio para guardar los datos 
    function saveData($name,$lastname,$age){
        //obtenemos los datos actuales del archivo 
        $data=getData();

        //crear nuevo registro
        $record = [
            "name"=> $name,
            "lastname" => $lastname,
            "age"=> $age
        ];

        //agregar el nuevo registro al array de datos 
        $data[] = $record;

        //convertir el array a formato json y lo guardamos 
        $data = json_encode($data);
        file_put_contents(FILE,$data);
    }
    //Funcion para modificar registro
    function updateData($cod,$name,$lastname,$age){
        //obtenemos los datos actuales del archivo 
        $data=getData();

        //Actualizamo el registro correspondiente 
        $data[$cod]['name']=$name;
        $data[$cod]['lastname']=$lastname;
        $data[$cod]['age']=$age;

        //convertir a formato json
        $data = json_encode($data);
        file_put_contents(FILE,$data);
    }

    //Funcion para elimiar
    function deleteData($cod){
        //Obtener datos
        $data= getData();

        //Eliminar registro
        unset($data[$cod]);

        //Reindexar el array
        $data = array_values($data);

        //Convertimos el array a formato json y guardamos el archivo
        $data=json_encode($data);
        file_put_contents(FILE, $data);

    }

?>